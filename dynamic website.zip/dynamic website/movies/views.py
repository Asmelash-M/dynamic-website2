from django.shortcuts import render, HttpResponse
from .models import *
from .forms import ContactForm
from django.core.mail import send_mail
from django.shortcuts import render, redirect
from .models import Contact
# Create your views here.
def home(request):
    Titles =Title.objects.all()
    data = {
        'Titles': Titles
    }
    
    return render(request, 'home.html', data)


def about(request):
    people = Person.objects.all()
    data = {
        'people': people
    }
    return render(request,'about.html', data)

def contact_us(request):
    if request.method == 'POST':
        form = ContactForm(request.POST)
        if form.is_valid():
            contact_message = Contact.objects.create(
                name=form.cleaned_data['name'],
                email=form.cleaned_data['email'],
                message=form.cleaned_data['message'],
            )
            return render(request, 'contact_us.html', {'form': ContactForm(), 'message': 'Your message has been sent.'})
    else:
        form = ContactForm()

    return render(request, 'contact_us.html', {'form': form})
def movies(request):
    return render(request,'movies.html')